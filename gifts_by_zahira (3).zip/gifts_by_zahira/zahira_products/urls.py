from django.urls import path
from .import views
from .views import  product_list, customer_profile,loginview


urlpatterns = [
   path('',views.home,name='home'),
   path('accounts/login/',views.loginview,name="login"),
   path('accounts/sign_up/',views.sign_up,name='signup'),
   path('product_details',views.product_list),
   path('customer_details',views.customer_profile),
]

