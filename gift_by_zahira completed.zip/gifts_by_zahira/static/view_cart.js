function removeFromCart() {
    // Get the form element
    var form = document.getElementById('removeForm');
    // Submit the form
    form.submit();
}
