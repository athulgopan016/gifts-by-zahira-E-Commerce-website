from django.shortcuts import render, redirect
from .models import Admin, Product, Customer
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User



@login_required
def home(request):
    return render(request,"index.html")



def admin_dashboard(request):
    return render(request, 'admin.html')

def product_list(request):
    products = Product.objects.all()
    return render(request, 'products.html', {'products': products})

def customer_profile(request):
    customers = Customer.objects.all()
    return render(request, 'customers.html', {'customers': customers})

# views.py
def loginview(request):
    if request.method == 'POST':
        uname = request.POST['username']
        pwd = request.POST['password']
        user = authenticate(request, username=uname, password=pwd)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, "Registration/login.html", {"msg": "Invalid login"})
    else:
        return render(request, "Registration/login.html")


def sign_up(request):
    try:
        if request.method == "POST":
            form = UserCreationForm(request.POST)
            if form.is_valid():
                # Save the user if the form is valid
                form.save()
                return redirect('login')
            else:
                # Return the form with errors if it's not valid
                return render(request, 'sign_up.html', {'form': form, 'msg': 'Invalid signup'})
        else:
            # Render the form for GET requests
            form = UserCreationForm()
            return render(request, 'sign_up.html', {'form': form})
    except Exception as e:
        print(e)
        # Handle other exceptions if needed
        form = UserCreationForm()
        return render(request, 'sign_up.html', {'form': form})
