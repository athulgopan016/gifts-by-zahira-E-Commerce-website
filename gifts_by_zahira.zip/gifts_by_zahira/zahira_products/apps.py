from django.apps import AppConfig


class ZahiraProductsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'zahira_products'
